class VideoStoragePort {
  async getVideoUrl(path) {
    throw new Error('Method not implemented');
  }
  
  async uploadVideo(file) {
    throw new Error('Method not implemented');
  }
}

