class SpiritRepositoryPort {
  async getAllSpirits() {
    throw new Error('Method not implemented');
  }
  
  async getSpiritsByCategory(category) {
    throw new Error('Method not implemented');
  }
  
  async getSpiritById(id) {
    throw new Error('Method not implemented');
  }
}

