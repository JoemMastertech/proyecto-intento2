class ImageStoragePort {
  async getImageUrl(path) {
    throw new Error('Method not implemented');
  }
  
  async uploadImage(file) {
    throw new Error('Method not implemented');
  }
}

